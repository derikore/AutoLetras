package com.autoletras.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MusicNotificationListener : NotificationListenerService() {

    private var lastQuery = ""

    override fun onListenerConnected() {
        super.onListenerConnected()
        checkActiveSessions()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        if (sbn.packageName == packageName) return

        // 1. Tenta capturar via MediaSession oficial do Android (funciona com YouTube, Spotify, players locais, Chrome, etc.)
        checkActiveSessions()

        // 2. Fallback caso o player use notificacao de midia tradicional
        val extras = sbn.notification.extras
        val template = extras.getString(Notification.EXTRA_TEMPLATE)
        val isMediaNotif = template?.contains("MediaStyle") == true ||
                sbn.notification.category == Notification.CATEGORY_TRANSPORT ||
                isKnownMusicApp(sbn.packageName)

        if (isMediaNotif) {
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val artist = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            if (title.isNotBlank()) {
                handleTrackDetected(title, artist)
            }
        }
    }

    private fun isKnownMusicApp(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("youtube") || p.contains("spotify") || p.contains("music") ||
               p.contains("deezer") || p.contains("player") || p.contains("vlc") ||
               p.contains("revanced") || p.contains("soundcloud") || p.contains("musicolet")
    }

    private fun checkActiveSessions() {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, MusicNotificationListener::class.java)
            val controllers: List<MediaController> = manager.getActiveSessions(component)
            for (controller in controllers) {
                val state = controller.playbackState?.state
                if (state == PlaybackState.STATE_PLAYING) {
                    val meta = controller.metadata
                    if (meta != null) {
                        val title = meta.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
                        val artist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_AUTHOR) ?: ""
                        if (title.isNotBlank()) {
                            handleTrackDetected(title, artist)
                            return
                        }
                    }
                }
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    private fun cleanYoutubeTitle(raw: String): String {
        var s = raw
        val regexes = listOf(
            "\(.*?official.*?\)", "\[.*?official.*?\]",
            "\(.*?oficial.*?\)", "\[.*?oficial.*?\]",
            "\(.*?video.*?\)", "\[.*?video.*?\]",
            "\(.*?vídeo.*?\)", "\[.*?vídeo.*?\]",
            "\(.*?audio.*?\)", "\[.*?audio.*?\]",
            "\(.*?lyrics.*?\)", "\[.*?lyrics.*?\]",
            "\(.*?letra.*?\)", "\[.*?letra.*?\]",
            "\(hd\)", "\[hd\]", "\(4k\)", "\[4k\]",
            "\(ao vivo.*?\)", "\[ao vivo.*?\]",
            "clipe oficial", "vídeo oficial", "video oficial", "legendado", "tradução"
        )
        for (r in regexes) {
            s = s.replace(Regex(r, RegexOption.IGNORE_CASE), "")
        }
        return s.replace(Regex("\s+"), " ").trim()
    }

    private fun handleTrackDetected(rawTitle: String, rawArtist: String) {
        val cleanTitle = cleanYoutubeTitle(rawTitle)
        val cleanArtist = rawArtist
            .replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("VEVO$", RegexOption.IGNORE_CASE), "")
            .trim()

        if (cleanTitle.length < 2) return

        val query = if (cleanTitle.contains("-")) {
            cleanTitle
        } else {
            "$cleanArtist $cleanTitle".trim()
        }

        if (query.equals(lastQuery, ignoreCase = true)) return
        lastQuery = query

        LyricsRepository.update(cleanTitle, cleanArtist, "⏳ Buscando letra para "$cleanTitle"...")

        thread {
            fetchLyricsFromLrcLib(cleanTitle, cleanArtist, query)
        }
    }

    private fun fetchLyricsFromLrcLib(title: String, artist: String, query: String) {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://lrclib.net/api/search?q=$encoded")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 7000
                readTimeout = 7000
                setRequestProperty("User-Agent", "AutoLetrasAndroid/1.0")
            }

            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonArray = JSONArray(response)

                if (jsonArray.length() > 0) {
                    val item = jsonArray.getJSONObject(0)
                    val trackName = item.optString("trackName", title)
                    val artistName = item.optString("artistName", artist)
                    var plainLyrics = item.optString("plainLyrics", "")

                    if (plainLyrics.isBlank() || plainLyrics == "null") {
                        // Caso so tenha letra sincronizada, remove os timestamps [00:12.34]
                        val synced = item.optString("syncedLyrics", "")
                        plainLyrics = synced.replace(Regex("\[\d+:\d+(\.\d+)?\]"), "").trim()
                    }

                    if (plainLyrics.isNotBlank() && plainLyrics != "null") {
                        LyricsRepository.update(trackName, artistName, plainLyrics)
                        sendLyricsNotification(trackName, artistName, plainLyrics)
                        return
                    }
                }
            }
            LyricsRepository.update(title, artist, "😕 Letra não encontrada automaticamente para:
"$query"")
        } catch (e: Exception) {
            LyricsRepository.update(title, artist, "Erro de conexão ao buscar a letra: ${e.localizedMessage}")
        }
    }

    private fun sendLyricsNotification(title: String, artist: String, lyrics: String) {
        val channelId = "autoletras_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Letras Encontradas",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerta rápido quando uma música começa a tocar"
            }
            nm.createNotificationChannel(channel)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val preview = lyrics.lines().filter { it.isNotBlank() }.take(2).joinToString(" / ")

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("🎵 Letra: $title - $artist")
            .setContentText(preview.ifBlank { "Toque para abrir a letra completa" })
            .setStyle(NotificationCompat.BigTextStyle().bigText(lyrics.take(350) + "

[Toque para ler a letra inteira...]"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        nm.notify(1001, notification)
    }
}
