package com.autoletras.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusBadge: TextView
    private lateinit var permissionButton: Button
    private lateinit var songTitleText: TextView
    private lateinit var artistText: TextView
    private lateinit var lyricsText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Solicita permissao de exibir notificacoes no Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        // Layout moderno em Modo Escuro criado direto via codigo (sem risco de erro de XML)
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(48, 64, 48, 48)
        }

        val appHeader = TextView(this).apply {
            text = "🎵 AutoLetras"
            textSize = 24f
            setTextColor(Color.parseColor("#1DB954"))
            setTypeface(null, Typeface.BOLD)
        }

        statusBadge = TextView(this).apply {
            textSize = 13f
            setPadding(0, 8, 0, 24)
        }

        permissionButton = Button(this).apply {
            text = "Ativar Permissão de Leitura de Música"
            setBackgroundColor(Color.parseColor("#1DB954"))
            setTextColor(Color.BLACK)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        songTitleText = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 36, 0, 4)
        }

        artistText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#B3B3B3"))
            setPadding(0, 0, 0, 32)
        }

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        lyricsText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#E8E8E8"))
            setLineSpacing(14f, 1.15f)
            gravity = Gravity.START
        }

        scrollView.addView(lyricsText)

        rootLayout.addView(appHeader)
        rootLayout.addView(statusBadge)
        rootLayout.addView(permissionButton)
        rootLayout.addView(songTitleText)
        rootLayout.addView(artistText)
        rootLayout.addView(scrollView)

        setContentView(rootLayout)

        LyricsRepository.onUpdate = {
            runOnUiThread { refreshUI() }
        }
        refreshUI()
    }

    override fun onResume() {
        super.onResume()
        checkPermissionStatus()
        refreshUI()
    }

    private fun checkPermissionStatus() {
        val cn = ComponentName(this, MusicNotificationListener::class.java)
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        val enabled = flat != null && flat.contains(cn.flattenToString())

        if (enabled) {
            statusBadge.text = "✅ Monitoramento ativo em 2º plano (Pronto para detectar Play)"
            statusBadge.setTextColor(Color.parseColor("#1DB954"))
            permissionButton.text = "Configurações de Permissão (Já Ativo)"
        } else {
            statusBadge.text = "⚠️ Permissão pendente: clique no botão abaixo e ative o AutoLetras"
            statusBadge.setTextColor(Color.parseColor("#FFAB00"))
            permissionButton.text = "1. Ativar Permissão de Leitura de Música"
        }
    }

    private fun refreshUI() {
        songTitleText.text = LyricsRepository.currentTitle
        artistText.text = LyricsRepository.currentArtist
        lyricsText.text = LyricsRepository.currentLyrics
    }

    override fun onDestroy() {
        super.onDestroy()
        LyricsRepository.onUpdate = null
    }
}
