package com.autoletras.app

object LyricsRepository {
    var currentTitle: String = "Nenhuma música detectada ainda"
    var currentArtist: String = "Dê play no YouTube, Spotify ou outro player"
    var currentLyrics: String = "Assim que você der play em qualquer aplicativo de música ou vídeo, a notificação vai subir automaticamente e a letra completa aparecerá aqui!"
    var onUpdate: (() -> Unit)? = null

    fun update(title: String, artist: String, lyrics: String) {
        currentTitle = title
        currentArtist = artist
        currentLyrics = lyrics
        onUpdate?.invoke()
    }
}
